# Where are the cats?

The author of the cats has asked that we don't freely distribute the cat assets in GitHub. 

If you want to make custom cat colors or animations, you'll need to buy the [catset](https://seethingswarm.itch.io/catset) on itch and customize it from there.